For Gradient Descent, 0 initialization of the weight vector is assumed.

The code will notify the parameters for which a run fails to be within a threshold of my output.
Based on various parameters, the CF & GD methods are tested along with the respective error method.
The predict method is not directly tested, as its respective logic is used in the error method.